const player = videojs("my-video");

const vidcontainer = document.getElementById("vidcontainer");

function fetchVideo() {
  const urlInput = document.getElementById("terabox-url").value;
  const videoId = extractVideoId(urlInput);
  const videoUrl = `https://apis.forn.fun/tera/m3u8.php?id=${videoId}`;

  loadVideo(videoUrl);
}

function extractVideoId(url) {
  const parts = url.split("/");
  return parts[parts.length - 1];
}

function loadVideo(videoUrl) {
  player.src({
    type: `application/x-mpegURL`,
    src: `${videoUrl}`,
  });

  vidcontainer.style.display = "flex";
}

function toggleNightMode() {
  document.body.classList.toggle("dark-mode");
}

async function pasteFromClipboard() {
  try {
    const text = await navigator.clipboard.readText();
    document.getElementById("terabox-url").value = text;
  } catch (err) {
    console.error("Failed to read clipboard contents: ", err);
  }
}
